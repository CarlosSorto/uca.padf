<?php $__env->startSection('content'); ?>
    <section class="pt6-l pt5">
        <div class="img-cover relative mt3">
            <img src="storage/<?php echo e($cover->get('acerca-del-portal')->image); ?>" alt="" width="100%" class="h-75">
            <div class="img-overlay h-75"></div>
            <div class="text-overlay pl6-l pl4">
                <h1 class="white ttu fw5 f1-l f3 mb0"><?php echo e($cover->get('acerca-del-portal')->title); ?></h1>
                <hr class="ba bw1 w-50" align="left">
                <p class="mw6 lh-copy f5 dn db-l">
                    <?php echo e($cover->get('acerca-del-portal')->description); ?>

                </p>
            </div>
        </div>
    </section>
    <?php echo $content->get('acerca_del_portal_iniciativa'); ?>

    <?php echo $content->get('acerca_del_portal_porque_surgio'); ?>

    <?php echo $content->get('acerca_del_portal_beneficios'); ?>

    <section class="bg--light-blue pv4">
        <?php echo $content->get('acerca_del_portal_organizaciones'); ?>

        <div class="cf w-60-l w-80 center tc">
            <?php $__currentLoopData = $founders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $founder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="fl w-20-l w-50-m w-100 pa2">
                    <div class="ba bg-white b--black-10 mv4 w-100 mw6 pa4 h6 shadow-5">
                        <img src="storage/<?php echo e($founder->image); ?>" alt="<?php echo e($founder->name); ?>" class="w-100">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <section class="pv4">
       <div class="center w-60-l w-80">
           <h1 class="tc text--blue fw4 f2">Galería</h1>
           <div class="owl-carousel owl-theme center" id="owl-galery" data-slider-id="1">
               <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <img class="owl-lazy img-carousel" data-src="storage/<?php echo e($gallery->image); ?>" alt="<?php echo e($gallery->name); ?>">
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
           <div class="owl-thumbs" data-slider-id="1">
               <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <button class="owl-thumb-item">
                       <img class="owl-lazy tc" src="storage/<?php echo e($gallery->image); ?>" alt="<?php echo e($gallery->name); ?>">
                   </button>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
       </div>
   </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>