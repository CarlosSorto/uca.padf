<?php $__currentLoopData = $items->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="fl dn db-l pv3 hover-bg--purple <?php echo e(url($item->link()) == url()->current() ? 'bg--purple' : ''); ?>">
        <a class="f6 fw4 no-underline white ph3" href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
