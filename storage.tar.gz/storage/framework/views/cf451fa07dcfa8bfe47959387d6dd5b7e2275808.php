<?php $__currentLoopData = $items->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="dib-l tc <?php echo e(!$loop->last ? 'br-l' : ''); ?>  b--white mv4">
        <a class="f6-l fw4 no-underline white hover-text--purple ph4-l f5" href="<?php echo e($item->url); ?>"> <?php echo e($item->title); ?>

        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
