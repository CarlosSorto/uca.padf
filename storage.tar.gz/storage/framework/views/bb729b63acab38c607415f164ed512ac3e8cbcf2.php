<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('organization.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <section class="pt6-l pt5 pb5 bg--light-blue">
        <div class="w-60-l w-80 center mt5">
            <?php if($errors): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <h1 class="text--blue fw4 f2">Registro de Organización</h1>
            <div class="bg-white pa3 mb5">
                <h2 class="text--blue fw4 f3">Datos de la institución</h2>
                <div class="cf">
                    <div class="fl w-100 w-50-ns ph3">
                        <div class="mb4">
                            <input id="title" class="input-reset f-input bn pa2 mb2 db w-100" type="text" name="name" placeholder="Nombre*" value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="mb4">
                            <input id="author" class="input-reset f-input bn pa2 mb2 db w-100" type="text" name="phone" placeholder="Teléfono*" value="<?php echo e(old('phone')); ?>">
                        </div>
                        <div class="mb4">
                            <input id="date" class="input-reset f-input bn pa2 mb2 db w-100" type="text" name="email" placeholder="Correo electrónico*" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="mb4">
                            <input id="description" class="input-reset f-input bn pa2 mb2 db w-100" type="text" name="description" placeholder="Descripción corta*" value="<?php echo e(old('description')); ?>">
                        </div>
                        <div class="mb4">
                            <textarea cols="30" rows="5" class="f-textarea w-100 bo--light-blue-50" placeholder="Descripción larga*" name="long_description">
                                <?php echo e(old('long_description')); ?>

                            </textarea>
                        </div>
                    </div>
                    <div class="fl w-100 w-50-ns ph3">
                        <div class="mb4">
                            <select class="w-100 f-select text--light-blue-50" name="classification_id">
                                <option value="" class="text--light-blue-50">Seleccione un Categoría</option>
                                <?php $__currentLoopData = $classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($classification->id); ?>" class="text--light-blue-50" <?php echo e((old("classification_id") == $classification->id ? "selected":"")); ?>>
                                        <?php echo e($classification->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb4">
                            <select class="w-100 f-select text--light-blue-50" name="workares">
                                <option value="" class="text--light-blue-50">Seleccione una Área de especialización</option>
                                <?php $__currentLoopData = $work_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($work_area->id); ?>" class="text--light-blue-50" <?php echo e((old("work_area_id") == $work_area->id ? "selected":"")); ?>>
                                        <?php echo e($work_area->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb4">
                            <select class="w-100 f-select text--light-blue-50" name="country_id">
                                <option value="" class="text--light-blue-50">Seleccione un país</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" class="text--light-blue-50" <?php echo e((old("country_id") == $country->id ? "selected":"")); ?>>
                                        <?php echo e($country->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <input type="file" style="cursor:pointer" name="image" class="dib absolute overflow-hidden o-0 f5 fw4 bo--purple link ba bw1 pv2 text--purple hover-bg--purple hover-white bg-animate">
                            <label for="" style="cursor:pointer" class="dib f5 fw4 bo--purple link ba bw1 pv2 ph5 text--purple hover-bg--purple hover-white bg-animate">Subir Logo</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white pa3">
                <h2 class="text--blue fw4 f3">Datos del solicitante</h2>
                <div class="cf">
                    <div class="fl w-100 w-third-ns pa2">
                        <input class="input-reset f-input bn pa2 mb2 db w-100" type="text" placeholder="Nombre del solicitante*" name="applicant" value="<?php echo e(old('applicant')); ?>">
                    </div>
                    <div class="fl w-100 w-third-ns pa2">
                        <input class="input-reset f-input bn pa2 mb2 db w-100" type="text" placeholder="Institución*" name="institution" value="<?php echo e(old('institution')); ?>">
                    </div>
                    <div class="fl w-100 w-third-ns pa2">
                        <input class="input-reset f-input bn pa2 mb2 db w-100" type="text" placeholder="Cargo*" name="position" value="<?php echo e(old('position')); ?>">
                    </div>
                </div>
                <div class="tr mt4 mb3">
                    <button type="submit" class="f5 fw4 bo--purple link ba bw1 pv2 ph5 text--purple hover-bg--purple hover-white bg-animate">Enviar</button>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>