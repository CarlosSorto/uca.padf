<?php $__env->startSection('content'); ?>
    <section class="pt6-l pt5">
        <div class="img-cover relative mt3">
            <img src="<?php echo e($cover->get('formacion')->image); ?>" alt="" width="100%" class="h-75">
            <div class="img-overlay h-75"></div>
            <div class="text-overlay pl6-l pl4">
                <h1 class="white ttu fw5 f1-l f3 mb0"><?php echo e($cover->get('formacion')->title); ?></h1>
                <hr class="ba bw1 w-50" align="left">
                <p class="mw6 lh-copy f5 dn db-l">
                    <?php echo e($cover->get('formacion')->description); ?>

                </p>
            </div>
        </div>
    </section>
    <?php echo $content->get('formacion_introduccion'); ?>

    <formations></formations>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>