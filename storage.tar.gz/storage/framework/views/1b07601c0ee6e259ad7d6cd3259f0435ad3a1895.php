<?php $__env->startSection('content'); ?>
    <section class="pt6-l pt5 mb2">
        <div class="w-80 w-70-l center cf mt5">
            <h1 class="text--blue fw4 f2">Directorio de Organizaciones</h1>
            <div class="fl w-100 w-40-l pa2">
                <div class="pa5 shadow-5">
                    <img src="/<?php echo e($organization->image); ?>" alt="">
                </div>
            </div>
            <div class="fl w-100 w-60-l ph4">
                <h2 class="text--blue fw3 f3 mb0"><?php echo e($organization->name); ?></h2>
                <hr class="ba bo--light-blue-50 mw3" align="left">
                <p class="lh-copy silver"><?php echo e($organization->description); ?></p>
                <p class="f5 fw6">Clasificación contemporanea</p>
                <p class="silver lh-copy"><?php echo e($organization->classification->name); ?></p>
                <div class="mv4">
                    <p class="ttu text--light-blue-50 fw6 f5">Áreas de Trabajo</p>
                    <?php $__currentLoopData = $organization->work_areas()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="ba br1 bw1 dib-l tc pa2 silver b--silver f6 mr1"><?php echo e($work_area->name); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <section class="pb4">
       <div class="w-80 w-70-l center">
           <h1 class="f2 fw4 text--blue">Información de Contacto</h1>
           <div class="cf">
                <div class="fl w-100 w-70-ns pa2">
                    <div class="bg-white w-100 h5" id="map">
                    </div>
                </div>
                <div class="fl w-100 w-30-ns pa2">
                    <div class="relative pl4 mb4">
                        <span class="icon-mail silver f4 absolute top-0 left-0"></span>
                        <p class="silver fw6 f6 mb2">Correo Electrónico</p>
                        <p class="fw3 silver f6 ma0"><a href="mailto:info@example.com" class="link silver"><?php echo e($organization->email); ?></a></p>
                    </div>
                    <div class="relative pl4 mb4">
                        <span class="icon-phone silver f4 absolute top-0 left-0"></span>
                        <p class="silver fw6 f6 mb2">Teléfono</p>
                        <p class="fw3 silver f6 ma0"><?php echo e($organization->phone); ?></p>
                    </div>
                    <div class="relative pl4">
                        <span class="icon-ubicacion silver f4 absolute top-0 left-0"></span>
                        <p class="silver fw6 f6 mb2">Dirección</p>
                        <p class="fw3 f6 lh-copy silver ma0">Ave. El Espino, Urb. Madre Selva No.65, Antiguo Cuscatlán, La Libertad, El Salvador</p>
                    </div>
                </div>
           </div>
       </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>