<?php $__currentLoopData = $items->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="mv4 bb b--white pb4">
        <a href="<?php echo e($item->url); ?>" class="link f3 white"><?php echo e($item->title); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
