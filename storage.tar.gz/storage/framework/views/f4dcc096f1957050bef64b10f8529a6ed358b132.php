<footer class="bg--blue">
    <div class="pv4">
        <div class="cf w-70-ns center mb5">
            <div class="fl w-100 w-50-ns pa2 dn dn-m db-ns">
                <?php echo $content->get('links_footer'); ?>

            </div>
            <div class="fl w-50 w-25-ns w-50-m pa2 mt5">
                <img src="<?php echo e(config('app.url') .'/'. app('voyager')->setting('logo_usaid')); ?>" alt="">
            </div>
            <div class="fl w-50 w-25-ns pa2 w-50-m mt5">
                <img src="<?php echo e(config('app.url') .'/'. app('voyager')->setting('logo_padf')); ?>" alt="">
            </div>
        </div>
        <div class="dt w-100 center tc">
            <ul class="dtc list">
                <?php echo e(menu('footer', 'partials.menu.footer')); ?>

            </ul>
        </div>
    </div>
    <div class="tc bg--light-blue-10 pa1 pa3 center">
        <h6 class="white f6 ma0 pa0 fw3 tc">&copy; <?php echo e(date('Y')); ?> UCA</h6>
    </div>
</footer>
