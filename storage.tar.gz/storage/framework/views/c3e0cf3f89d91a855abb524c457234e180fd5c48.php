<?php $__env->startSection('content'); ?>
    <section class="pv6-l pv5 ph5 mb4">
        <div class="w-6-l w-80 center cf mt5">
            <h1 class="text--blue fw4 f2">Repositorio</h1>
            <div class="fl w-100 w-70-ns pa2">
                <h2 class="text--blue fw3 f3 w-50-l w-100"><?php echo e($document->title); ?></h2>
                <hr class="ba bo--light-blue-50 mw3" align="left">
                <p class="silver lh-copy"><?php echo e($document->description); ?></p>
                <p class="mv3"><span class="b">Autor:</span> <?php echo e($document->author); ?></p>
                <p class="mv3"><span class="b">Publicación:</span> <?php echo e($document->published_date); ?></p>
                <p class="mv3"><span class="b">País:</span> <?php echo e($document->country->name); ?></p>
                <p class="mv3"><span class="b">Organización:</span> <?php echo e($document->organization->name); ?></p>
                <div class="mv4">
                    <p class="ttu text--light-blue-50 fw6 f5">Categorización Tematica</p>
                    <?php $__currentLoopData = $document->topics()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="ba br1 dib-l tc pa2 silver b--silver f6 mr1"><?php echo e($topic->name); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="fl w-100 w-30-ns pa2">
                <img src="/storage/documents/o75e3ykM05QMezijEwm1SzIdeXzH4BXIqSVz8dR3.png" alt="">
                <a href="/<?php echo e($document->file); ?>" target="_blank" class="f5 fw4 ph2 db mt4 tc bo--purple link ba bw1 pv2 text--purple hover-bg--purple hover-white bg-animate">Descargar (75.41 kB)</a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>