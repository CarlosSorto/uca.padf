<?php $__currentLoopData = $items->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="dib-l link gray mh3 fw5 f6" href="<?php echo e($item->url); ?>" title="Contactenos"><?php echo e($item->title); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
