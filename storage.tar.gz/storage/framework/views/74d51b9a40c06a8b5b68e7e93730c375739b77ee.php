<?php if(isset($dataTypeContent->{$row->field})): ?>
    <a class="fileType" href="/storage/<?php echo e($dataTypeContent->{$row->field}); ?>">Download</a>
<?php endif; ?>
<input type="file" name="<?php echo e($row->field); ?>">